import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CoffeeDesc extends StatelessWidget {
  final String coffeeImagePath;
  final String coffeeName;

  CoffeeDesc({
    required this.coffeeImagePath,
    required this.coffeeName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(120, 35, 35, 35),
      body: ListView(
        children: [
          Container(
            child: Card(
              color: Colors.transparent,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    coffeeImagePath,
                    width: 410,
                    height: 410,
                  ),
                  Text(
                    coffeeName,
                    style: GoogleFonts.gfsDidot(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 199, 181, 173)),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Text(
                    'enjoy a cup of coffee in the various types of menus that we serve deliciously',
                    style: GoogleFonts.poppins(
                        fontSize: 16, color: Colors.white70),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 55,
                  ),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                        color: Color.fromARGB(250, 195, 185, 176),
                        borderRadius: BorderRadius.circular(13)),
                    child: const Icon(
                      Icons.arrow_right_alt,
                      size: 52,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class MyWidget extends StatelessWidget {
  const MyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
